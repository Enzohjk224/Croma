import { Stack, Tabs,  } from "expo-router";
import {View, Text, StyleSheet} from "react-native"

import {ChartPieSlice, UserCircle, BookOpenText} from "phosphor-react-native";

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: "#D74818",
          height: 80,
          paddingTop: 15,
        },
        tabBarShowLabel: false,
        tabBarActiveTintColor: "#1A0521",
        tabBarInactiveTintColor: "#f4f4f4",
      }} 
    >
      <Tabs.Screen name="Principal" options={{
        tabBarIcon: ({color}) => (
        <View>
          <ChartPieSlice size={32} color={color} weight="fill"/>
          <Text style={{color: color, fontSize: 10}}>Grafico</Text>
        </View>
        ),
        
      }}
      />
      <Tabs.Screen name="Receitas" options={{
        tabBarIcon: ({color}) => (
        <View>
          <BookOpenText size={32} color={color} weight="fill"/>
          <Text style={{color: color, fontSize: 11}}>Receitas</Text>
        </View>
        ),
        
      }}
      />
      <Tabs.Screen name="Perfil" options={{
        tabBarIcon: ({color}) => (
        <View>
          <UserCircle size={32} color={color} weight="fill"/>
          <Text style={{color: color, fontSize: 11}}>Perfil</Text>
        </View>
        ),
        
      }}
      />
    </Tabs>
  );
}

export const styles = StyleSheet.create({
  textoBotao:{
    fontSize: 11,
  },
});