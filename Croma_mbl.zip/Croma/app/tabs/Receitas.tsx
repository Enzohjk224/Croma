import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { BookmarkSimple } from "phosphor-react-native";
import {Pressable, StyleSheet, Text, TextInput, View, Image} from "react-native"

export default function Receitas(){

    const router = useRouter();
      
          function handleRDetalhes(){
              router.navigate("/stacks/Detalhes");
      
          }

    return(
        <LinearGradient style={styles.container} colors={["#D74818", "#1A0521",]}
            start={{x: 0, y: 4}}
            end={{x: 4, y: 0}}
            >
                
            <Text>Receitas</Text>

            <View style={styles.inputContainer}>
                    <TextInput style={styles.input}
                      placeholder="Receitas..."
                      placeholderTextColor="#f4f4f4"
                    />
                  </View>
                  <View style={styles.content}>
                    <View style={styles.card}>

                        

                      <Pressable onPress={handleRDetalhes} style={styles.cardButton}>
                        <Image 
                          style={styles.cardImage} 
                          source={require("../assets/images/frangog.jpg")}
                        />
                        <View style={styles.cardInfo}>

                            

                            <Text style={styles.cardInfoTitle}>Frango Grelhado Com Limão</Text>
                            <Text style={styles.cardInfoSubTitles}>frango, alho, ...</Text>

                            <View style={styles.cardInfoBuy}>
                                <BookmarkSimple size={32} color="#1A0521" /*style={styles.cardInfoBuyText}*//>
                            </View>

                           
                        </View>
                      </Pressable>
            
                      
                    </View>
                  </View>
        </LinearGradient>
    );
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    paddingHorizontal: 20,
    },
    inputContainer: {
        width: "100%",
        height: 56,
        backgroundColor: "#D74818",
        borderRadius: 12,
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 20,
        gap: 10,
        marginBottom: 20,
    },
    input: {
        flex: 1,
        color: "#f4f4f4",

    },
    content: {
        width: "100%",
        gap: 20,
    },
    card:{
        width: "100%",
        height: 120,
        borderRadius: 12,
        backgroundColor: "#D74818",
        paddingHorizontal: 10,
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "space-between",
        gap: 10,

    },
    cardButton:{
        alignItems:  "flex-start",
        flexDirection: "row",
        gap: 10,
    },
    cardImage:{
        width: 90,
        height: 90,
        borderRadius: 12,
    },
    cardInfo:{
        height: "100%",
        gap: 10,

    },
    cardInfoTitle:{
        color: "#f4f4f4",
        fontSize: 14,
        fontWeight: "400",
        width: "100%",

    },
    cardInfoSubTitles:{
        color: "#f4f4f4",
        fontSize: 14,
        fontWeight: "300",
    },
    cardInfoBuy:{
        height: "30%",
        alignItems: "flex-end",
    },
});