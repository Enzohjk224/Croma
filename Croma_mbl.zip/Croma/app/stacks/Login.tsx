import {Text, View, StyleSheet, TextInput, TouchableOpacity} from "react-native"
import {LinearGradient} from "expo-linear-gradient"

import {Envelope, FacebookLogo, GoogleLogo, LockKey, } from "phosphor-react-native"
import { useRouter } from "expo-router";

export default function Login(){

    const router = useRouter();

    function handleHome(){
        router.navigate("/tabs/Principal");

    }

    return(
        //<View style={styles.container}>
            <LinearGradient style={styles.container} colors={["#D74818", "#1A0521",]}
            start={{x: 0, y: 4}}
            end={{x: 4, y: 0}}
            >

                <Text style={styles.bemVindo}> Bem Vindo Ao Croma!</Text>

                <View style={styles.content}>
                    <View style={styles.contentInput}>
                        <Envelope size={32} color="#757575"/>
                        <TextInput placeholder="Seu e-mail" style={styles.input} placeholderTextColor="#757575"/>
                    </View>

                    <View style={styles.contentInput}>
                        <LockKey size={32} color="#757575"/>
                        <TextInput placeholder="Sua Senha" style={styles.input} placeholderTextColor="#757575"/>
                    </View>

                </View>

                <TouchableOpacity onPress={handleHome} style={styles.buttonSignIn}>
                    <Text style={styles.buttonSignInText}>Entrar</Text>
                </TouchableOpacity>

                <View style={styles.containerSeparator}>
                    <View style={styles.separator}/>
                    <Text style={styles.separatorText}> ou continuar com</Text>
                    <View style={styles.separator}/>
                </View>
                
                <View style={styles.footer}>
                    <TouchableOpacity style={styles.footerButton}>
                        <GoogleLogo color="#D74818" size={32} weight="fill" />
                    </TouchableOpacity>

                    
                    <TouchableOpacity style={styles.footerButton}>
                        <FacebookLogo color="#D74818" size={32} weight="fill" />
                    </TouchableOpacity>
                </View>

                <View style={styles.footer}>
                    <Text style={styles.footerText}>Não possui login ?</Text>
                    <TouchableOpacity>
                        <Text style={styles.footerButtonText}>Cadastre-se</Text>
                    </TouchableOpacity>
                </View>
            </LinearGradient>
        //</View>
    );
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        //backgroundColor: "#1A0521",
        alignItems: "center",
        paddingHorizontal: 20,
    },
    bemVindo:{
        color: "#f4f4f4",
        marginTop: 200,
        fontSize: 24,
        fontWeight: 600,
    },
    content:{
        width: "100%",
        marginTop: 50,
        alignItems: "center",
        gap: 20,
    },
    contentInput:{
        width: "100%",
        height: 56,
        backgroundColor: "#1f222a",
        borderRadius: 12,
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 20,
        gap: 10,
    },
    input:{
        flex: 1,
        color: "#f4f4f4",
    },
    buttonSignIn:{
        backgroundColor: "#D74818",
        width: "100%",
        height: 56,
        borderRadius: 32,
        alignItems: "center",
        justifyContent: "center",
        marginTop: 40,
    },
    buttonSignInText:{
        color: "#f4f4f4",
        fontSize: 16,
        fontWeight: 800,
    },
    containerSeparator:{
        width: "100%",
        marginTop: 50,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 10,
    },
    separatorText:{
        color: "#f4f4f4",
        fontSize: 16,
        fontWeight: "400",
    },
    separator:{
        height: 1,
        backgroundColor: "#757575",
        flex: 1,
    },
    footer:{
        marginTop: 50,
        flexDirection: "row",
        gap: 10,
    },
    footerButton:{
        width: 100,
        height: 60,
        backgroundColor: "#1f222a",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
    },
    footerText:{
        color: "#f4f4f4",
        fontSize: 16,
        fontWeight: "400",
    },
    footerButtonText:{
        color: "#D74818",
        fontSize: 16,
        fontWeight: "400",
    },
});