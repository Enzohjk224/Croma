import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { ArrowLeft, Bookmark, DotsThree, MapPin } from "phosphor-react-native";
import { TouchableOpacity } from "react-native";
import { View, Text, StyleSheet, Image, ScrollView } from "react-native";


export default function Detalhes(){

    const router = useRouter();
    
        function VoltarR(){
            router.navigate("/tabs/Receitas");
    
        }

    return(
        <LinearGradient style={styles.container} colors={["#D74818", "#1A0521",]}
                    start={{x: 0, y: 4}}
                    end={{x: 4, y: 0}}
                    >

            <View style={styles.header}>
                <Image style={styles.headerImage} source={require("../assets/images/frangog.jpg")}/>
            
                <View style={styles.headerInfoButtons}>
                    <TouchableOpacity onPress={VoltarR}>
                        <ArrowLeft  size={32} color="#f4f4f4"/>
                    </TouchableOpacity>

                    <View style={styles.headerInfoButtonsRight}>
                        <Bookmark size={32} color="#f4f4f4"/>
                        <DotsThree size={32} color="#f4f4f4"/>
                    
                    
                    </View>
                </View>
            </View>

            <Text style={styles.infoNameText}>Receita</Text>
        
            <View style={styles.contentAddress}>
                <MapPin size={32} color="#D74818"/>
                <Text style={styles.contentAddressText}>Frango Grelhado com Alho</Text>
            </View>

            <View style={styles.separator} />

            <View style={styles.containerGalleryPhotos}>
                <Text style={styles.containerGalleryPhotosTextGallery}>Galeria de Fotos</Text>
                <Text style={styles.containerGalleryPhotosTextSellAll}>Ver Fotos</Text>
            </View>

            <ScrollView horizontal style={styles.contentPhotosContainer}>
                <Image style={styles.contentPhotosImage} source={require("../assets/images/frangog.jpg")}/>
                <Image style={styles.contentPhotosImage} source={require("../assets/images/frangog.jpg")}/>
                <Image style={styles.contentPhotosImage} source={require("../assets/images/frangog.jpg")}/>
                <Image style={styles.contentPhotosImage} source={require("../assets/images/frangog.jpg")}/>
            </ScrollView>

            <View style={styles.footer}>
                <View style={styles.footerContainerText}>
                    <Text style={styles.footerContainerTextMoney}>blablabla</Text>
                    <Text style={styles.footerContainerTextMonth}>blebleble</Text>
                </View>

                
                <TouchableOpacity  style={styles.button}>
                    <Text style={styles.buttonText}>Adicionar a Dieta</Text>
                </TouchableOpacity>
            </View>
        </LinearGradient>
    );
    
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        width: "100%",
        height: "40%",

    },
    headerImage: {
        width: "100%",
        height: "80%",
        borderRadius: 30,
        position: "absolute",
        marginTop: 65,

    },
    headerInfoButtons: {
        marginTop: 30,
        paddingHorizontal: 30,
        flexDirection: "row",
        justifyContent: "space-between",
    },
    headerInfoButtonsRight: {
        flexDirection: "row",
        gap: 10,
        marginTop: 40,
    },
    infoNameText: {
        color: "#f4f4f4",
        fontSize: 36,
        fontWeight: "bold",
        paddingHorizontal: 30,
        paddingTop: 20,
    },
    contentAddress: {
        flexDirection: "row",
        alignItems: "center",
        gap: 10,
        paddingHorizontal: 30,
        paddingTop: 15,
    },
    contentAddressText: {
        color: "#f4f4f4",
        fontSize: 12,
    },
    separator: {
        height: 1,
        backgroundColor: "#757575",
        marginHorizontal: 30,
        marginTop: 15,
    },
    containerGalleryPhotos: {
        flexDirection: "row",
        paddingHorizontal: 30,
        marginTop: 20,
        justifyContent: "space-between",
    },
    containerGalleryPhotosTextGallery: {
        fontSize: 18,
        color: "#f4f4f4",
        fontWeight: "bold",
    },
    containerGalleryPhotosTextSellAll: {
        fontSize: 16,
        color: "#D74818",
        fontWeight: 400,

    },
    contentPhotosContainer: {
        paddingHorizontal: 30,
        paddingTop: 15,

    },
    contentPhotosImage: {
        width: 100,
        height: 100,
        borderRadius: 12,
        marginRight: 10,
    },
    footer:{
        width: "100%",
        borderWidth: 1,
        height: 80,
        backgroundColor: "#1A0521",
        borderRightColor: "#1A0521",
        borderLeftColor: "#1A0521",
        borderTopColor: "#1A0521",
        borderTopLeftRadius: 26,
        borderTopRightRadius: 26,
        flex: 0.9,
        flexDirection: "row",
        paddingHorizontal: 10,
        gap: 10,
        alignItems: "center",

    },
    footerContainerText: {
        flexDirection: "row",
        alignItems: "center",
        gap: 10,
    },
    footerContainerTextMoney: {
        fontSize: 32,
        fontWeight: "bold",
        color: "#D74818",
    },
    footerContainerTextMonth: {
        fontSize: 12,
        fontWeight: 400,
        color: "#f4f4f4",
    },
    button: {
        backgroundColor: "#D74818",
        flex: 1,
        height: 56,
        borderRadius: 32,
        alignItems: "center",
        justifyContent: "center",
    },
    buttonText: {
        color: "#f4f4f4",
        fontSize: 12,
        fontWeight: 700,
    },

});