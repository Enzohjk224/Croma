/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/auth/Cadastro`; params?: Router.UnknownInputParams; } | { pathname: `/auth/Login`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Perfil`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Principal`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Receitas`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/auth/Cadastro`; params?: Router.UnknownOutputParams; } | { pathname: `/auth/Login`; params?: Router.UnknownOutputParams; } | { pathname: `/tabs/Perfil`; params?: Router.UnknownOutputParams; } | { pathname: `/tabs/Principal`; params?: Router.UnknownOutputParams; } | { pathname: `/tabs/Receitas`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/auth/Cadastro${`?${string}` | `#${string}` | ''}` | `/auth/Login${`?${string}` | `#${string}` | ''}` | `/tabs/Perfil${`?${string}` | `#${string}` | ''}` | `/tabs/Principal${`?${string}` | `#${string}` | ''}` | `/tabs/Receitas${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/auth/Cadastro`; params?: Router.UnknownInputParams; } | { pathname: `/auth/Login`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Perfil`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Principal`; params?: Router.UnknownInputParams; } | { pathname: `/tabs/Receitas`; params?: Router.UnknownInputParams; };
    }
  }
}
