import {StatusBar, StyleSheet, Text, View, TextInput, Pressable, Image,} from "react-native";


export default function Principal() {
  return (
    <View style={styles.container}>
      <StatusBar />
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerLeftText}>Croma</Text>
        </View>
        <View style={styles.headerRight}>
          <Text style={styles.headerRightText}>Texto da esquerda</Text>
        </View>
      </View>

      <Text style={styles.Croma}>Bem Vindo ao Croma!</Text>
      <View style={styles.inputContainer}>
        <TextInput style={styles.input}
          placeholder="refeições"
          placeholderTextColor="#1A0521"
        />
      </View>
      <View style={styles.content}>
        <View style={styles.card}>
          <Pressable style={styles.cardButton}>
            <Image 
              style={styles.cardImage} 
              source={require("../assets/images/frangog.jpg")}
            />
            <View style={styles.cardInfo}>
              <Text style={styles.cardInfoTitle}>Frango Grelhado</Text>
              <Text style={styles.cardInfoSubTitles}>frango, alho, ...</Text>
            
            </View>
          </Pressable>

          <View style={styles.cardInfoBuy}>
            <Text style={styles.cardInfoBuyText}>futuro Botão adicionar a dieta</Text>
          </View>
        </View>
      </View>
    </View>
  );
}


export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A0521",
    paddingHorizontal: 20,
  },
  header: {
    marginTop: 80,
    flexDirection: "row",
    justifyContent: "space-between"
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: "10",
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: "10",
  },
  headerLeftText: {
    color: "#D74818",
    fontSize: 24,
    fontWeight: 800,
  },
  headerRightText: {
    color: "#D74818",
    fontSize: 15,
    fontWeight: 800,
  },
  Croma: {
    color: "white",
    fontSize: 24,
    fontWeight: "800",
    textAlign: "center",
    paddingTop: 20,
    paddingBottom: 20,
  },
  inputContainer: {
    width: "100%",
    height: 56,
    backgroundColor: "#D74818",
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    gap: 10,
    marginBottom: 20,
  },
  input: {
    flex: 1,
    color: "#f4f4f4",

  },
  content: {
    width: "100%",
    gap: 20,
  },
  card:{
    width: "100%",
    height: 120,
    borderRadius: 12,
    backgroundColor: "#D74818",
    paddingHorizontal: 10,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,

  },
  cardButton:{
    alignItems:  "flex-start",
    flexDirection: "row",
    gap: 10,
  },
  cardImage:{
    width: 90,
    height: 90,
    borderRadius: 12,
  },
  cardInfo:{
    height: "100%",
    gap: 10,

  },
  cardInfoTitle:{
    color: "#f4f4f4",
    fontSize: 16,
    fontWeight: "400",

  },
  cardInfoSubTitles:{
    color: "#f4f4f4",
    fontSize: 14,
    fontWeight: "300",
  },
  cardInfoBuy:{
    height: "100%",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  cardInfoBuyText:{
    color: "#f4f4f4",
    fontSize: 10,
    fontWeight: "900",
  },
});